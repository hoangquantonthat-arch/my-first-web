HOANG QUAN — PHOTOGRAPHY & FILM

Cach mo website:
1. Giai nen file ZIP (neu ban dang mo file ZIP).
2. Giữ nguyên thư mục assets nằm cạnh index.html.
3. Nhấn đúp index.html để mở bằng Chrome hoặc Edge.

Da cap nhat:
- Thay ảnh chân dung bằng ảnh nàng thơ cầm bó hồng.
- Thay mục thiên nhiên bằng video Huế do bạn cung cấp.
- Video có hình xem trước chuyển động; nhấn vào thẻ để mở video lớn và dùng nút phát/dừng/âm lượng.

Lưu ý: Hãy giữ nguyên cấu trúc thư mục assets để ảnh và video hiển thị đúng. Website vẫn cần Internet cho Google Fonts và các ảnh mẫu còn lại.
